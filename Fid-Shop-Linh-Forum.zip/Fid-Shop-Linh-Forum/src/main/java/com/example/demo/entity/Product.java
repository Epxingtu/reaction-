package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "productid")
    Long productId;

    @ManyToOne
    @JoinColumn(name = "producttypeid", nullable = false)
    private ProductType productType;

    @Column(name = "productname", length = 50)
    String productName;

    @Column(name = "productbrand", length = 50)
    String productbrand;

    @Column(name = "productunit", length = 50)
    String productUnit;

    @Column(name = "productdetail",length = 10000)
    private String productDetail;

    @Column(name = "productprice")
    Double productPrice;

    @Column(name = "productsalepercent")
    int productSalePercent;

    @Column(name = "productstatus")
    int productStatus;

    @Column(name = "cputechnology")
    String cpuTechnology;

    @Column(name = "graphictechnology")
    String graphicTechnology;

    @Column(name = "storagetechnology")
    String storageTech;

    @Column(name = "screenresolution")
    String screenResolution;

    @Column(name = "conectivity")
    String conectivity;

    @Column(name = "camerafront")
    String cameraFront;

    @Column(name = "cameramain")
    String cameraMain;

    @Column(name = "battery")
    String batteryInfo;

    @Column(name = "design")
    String designInfo;

    @Column(name = "security")
    String securityTech;

    @Column(name = "keyboardtouchpad")
    String keyboard_touchpad;

    @Column(name = "information")
    String productInfo;

    @Column(name = "performance")
    String performanceInfo;

    @Column(name = "operatingsystem")
    String operatingSystem;

    @Column(name = "productimage")
    String imageFolder;
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<OrderDetail> orderDetail;
}
