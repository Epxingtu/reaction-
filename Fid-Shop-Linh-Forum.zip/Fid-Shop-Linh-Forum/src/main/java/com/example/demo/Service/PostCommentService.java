package com.example.demo.Service;

import com.example.demo.Repository.PostCommentRepository;
import com.example.demo.Repository.PostRepository;
import com.example.demo.entity.Post;
import com.example.demo.entity.PostComment;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PostCommentService {

    private final PostRepository postRepository;
    private final PostCommentRepository postCommentRepository;

    // Lấy danh sách bình luận của một bài viết
    public List<PostComment> getCommentsByPostId(Long postId) {
        return postCommentRepository.findByPost_PostId(postId);
    }

    // Thêm bình luận mới
    public PostComment addComment(Long postId, String content) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found"));

        PostComment comment = PostComment.builder()
                .post(post)
                .commentContent(content)
                .commentTime(LocalDateTime.now())
                .build();

        return postCommentRepository.save(comment);
    }

    // Xóa bình luận
    public void deleteComment(Long commentId) {
        postCommentRepository.deleteById(commentId);
    }
}
