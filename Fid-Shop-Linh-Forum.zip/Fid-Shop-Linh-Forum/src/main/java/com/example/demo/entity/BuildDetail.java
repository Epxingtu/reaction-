package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class BuildDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "builddetailid")
    Long buildDetailId;

    @ManyToOne
    @JoinColumn(name = "buildid", nullable = false)
    private PCBuild pcBuild;

    @ManyToOne
    @JoinColumn(name = "componentid", nullable = false)
    private Components components;

    @Column(name = "componentquantity", nullable = false)
    private int componentQuantity;
}
