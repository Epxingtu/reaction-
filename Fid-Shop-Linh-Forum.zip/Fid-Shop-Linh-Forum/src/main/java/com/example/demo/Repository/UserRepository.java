package com.example.demo.Repository;
import com.example.demo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    // Tìm kiếm user theo tên người dùng
    Optional<User> findByUserName(String userName);

    // Tìm kiếm user theo số điện thoại
    Optional<User> findByPhone(String phone);

    // Kiểm tra xem người dùng có tồn tại với tên người dùng
    boolean existsByUserName(String userName);

    // Kiểm tra xem người dùng có tồn tại với số điện thoại
    boolean existsByPhone(String phone);
}
