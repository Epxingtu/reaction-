package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;


@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class PostComment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "postcommentid")
    Long postCommentId;

    @ManyToOne
    @JoinColumn(name = "postid", nullable = false)
    Post post;

    @Column(name = "commentcontent")
    String commentContent;

    @Column(name = "commenttime")
    LocalDateTime commentTime;


}
