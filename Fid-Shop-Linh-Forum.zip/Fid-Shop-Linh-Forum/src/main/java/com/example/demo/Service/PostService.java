package com.example.demo.Service;

import com.example.demo.Repository.UserRepository;
import com.example.demo.Repository.PostRepository;
import com.example.demo.entity.Post;
import com.example.demo.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    // Phương thức tạo bài viết mới
    public Post createPost(Post post) {
        if (post.getUser() == null || post.getUser().getUserId() == 0) {
            throw new RuntimeException("User information is incomplete or invalid");
        }

        // Tìm kiếm user bằng Integer id
        User user = userRepository.findById(post.getUser().getUserId())
                .orElseThrow(() -> new RuntimeException("User with ID " + post.getUser().getUserId() + " not found"));

        // Gán lại user cho bài đăng
        post.setUser(user);
        post.setPostTime(LocalDateTime.now());

        return postRepository.save(post);
    }

    // Phương thức lấy tất cả bài viết
    public Iterable<Post> getAllPosts() {
        return postRepository.findAll();
    }

    // Phương thức lấy bài viết theo ID
    public Post getPostByIdPost(Long id) {  // Đổi kiểu id thành Integer
        return postRepository.findById(id).orElse(null);
    }

    // Phương thức cập nhật bài viết
    public Post updatePost(Long id, Post post) {  // Đổi kiểu id thành Integer
        if (postRepository.existsById(id)) {
            post.setPostId(id);  // Đảm bảo sử dụng id đã có để cập nhật
            return postRepository.save(post);
        }
        return null;
    }

    // Phương thức xóa bài viết
    public boolean deletePost(Long id) {  // Đổi kiểu id thành Integer
        if (postRepository.existsById(id)) {
            postRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
