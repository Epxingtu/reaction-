package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class Components {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "componentid")
    Long componentId;


    @Column(name = "componentname", length = 50)
    String productName;

    @Column(name = "manufactuner", length = 50)
    String manufactuner;

    @Column(name = "componenttype", length = 50)
    String componentType;

    @Column(name = "componentimage",length = 250)
    private String componentImage;

    @Column(name = "componentprice")
    Double componentPrice;

    @Column(name = "generation",length = 250)
    private int generation;
    @OneToMany(mappedBy = "components", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<BuildDetail> buildDetails;
}
