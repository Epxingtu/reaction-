package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;



@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class PostReaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "postreactionid")
    Long postReactionId;

    @ManyToOne
    @JoinColumn(name = "postid", nullable = false)
    Post post;

    @Column(name = "reactiontype", nullable = false)
    String reactionType;

    @Column(name = "count", nullable = false)
    private long count;

    public PostReaction( Post post, String reactionType, long count) {
        this.post = post;
        this.reactionType = reactionType;
        this.count = count;
    }
}
