package com.example.demo.Repository;

import com.example.demo.entity.Post;
import com.example.demo.entity.PostReaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostReactionRepository extends JpaRepository<PostReaction, Long> {

    // Lấy reaction của bài viết với loại cảm xúc cụ thể
    PostReaction findByPostAndReactionType(Post post, String reactionType);

    // Lấy tất cả reactions của một bài viết
    List<PostReaction> findByPost(Post post);

    // Đếm số lượng reaction cho một bài viết và loại cảm xúc cụ thể
    long countByPostAndReactionType(Post post, String reactionType);

    // Đếm tổng số reactions của một bài viết
    long countByPost(Post post);
}
