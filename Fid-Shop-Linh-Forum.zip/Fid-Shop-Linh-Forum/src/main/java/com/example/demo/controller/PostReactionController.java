package com.example.demo.controller;

import com.example.demo.entity.Post;
import com.example.demo.Service.PostReactionService;
import com.example.demo.Service.PostService;
import com.example.demo.entity.PostReaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@Controller
@RequestMapping("/home")
@RequiredArgsConstructor
public class PostReactionController {

    private final PostService postService;
    private final PostReactionService postReactionService;

    // Thêm hoặc xóa reaction
    @PostMapping("/react")
    public @ResponseBody Map<String, Integer> reactToPost(@RequestParam("postId") Long postId, @RequestParam("reactionType") String reactionType) {
        Post post = postService.getPostByIdPost(postId);

        // Toggle the reaction (add/remove)
        postReactionService.toggleReaction(post, reactionType);

        // Get updated total reactions count
        int totalReactions = postReactionService.getTotalReactions(post);
        return Map.of("totalReactions", totalReactions);
    }

    // Lấy tổng số reactions của bài viết
    @GetMapping("/reactions/{postId}")
    public @ResponseBody Map<String, Integer> getTotalReactions(@PathVariable Long postId) {
        Post post = postService.getPostByIdPost(postId);
        int totalReactions = postReactionService.getTotalReactions(post);
        return Map.of("totalReactions", totalReactions);
    }

    // Lấy 2 reactions phổ biến nhất của bài viết
    @GetMapping("/top-reactions/{postId}")
    public @ResponseBody List<PostReaction> getTopTwoReactions(@PathVariable Long postId) {
        Post post = postService.getPostByIdPost(postId);
        return postReactionService.getTopTwoReactions(post);
    }
}
