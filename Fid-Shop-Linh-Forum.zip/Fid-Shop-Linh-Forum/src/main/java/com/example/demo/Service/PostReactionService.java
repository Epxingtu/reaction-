package com.example.demo.Service;

import com.example.demo.entity.Post;
import com.example.demo.entity.PostReaction;
import com.example.demo.Repository.PostReactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PostReactionService {

    private final PostReactionRepository postReactionRepository;

    // Thêm reaction mới hoặc trả về reaction nếu đã tồn tại
    public PostReaction addReaction(Post post, String reactionType) {
        PostReaction existingReaction = postReactionRepository.findByPostAndReactionType(post, reactionType);
        if (existingReaction != null) {
            return existingReaction;
        } else {
            PostReaction postReaction = PostReaction.builder()
                    .post(post)
                    .reactionType(reactionType)
                    .count(1)
                    .build();
            return postReactionRepository.save(postReaction);
        }
    }

    // Đếm số lượng reactions cho từng loại cảm xúc
    public Map<String, Long> getReactionsCount(Post post) {
        List<PostReaction> reactions = postReactionRepository.findByPost(post);
        Map<String, Long> reactionsCount = new HashMap<>();
        for (PostReaction reaction : reactions) {
            reactionsCount.merge(reaction.getReactionType(), 1L, Long::sum);
        }
        return reactionsCount;
    }

    // Trả về tổng số reactions của bài viết
    public int getTotalReactions(Post post) {
        return (int) postReactionRepository.countByPost(post);
    }

    // Thêm hoặc xóa reaction của người dùng (toggle)
    public void toggleReaction(Post post, String reactionType) {
        PostReaction existingReaction = postReactionRepository.findByPostAndReactionType(post, reactionType);
        if (existingReaction != null) {
            postReactionRepository.delete(existingReaction);
        } else {
            PostReaction newReaction = new PostReaction();
            newReaction.setPost(post);
            newReaction.setReactionType(reactionType);
            newReaction.setCount(1);
            postReactionRepository.save(newReaction);
        }
    }

    // Lấy 2 reaction phổ biến nhất của bài viết
    public List<PostReaction> getTopTwoReactions(Post post) {
        List<PostReaction> reactions = postReactionRepository.findByPost(post);
        return reactions.stream()
                .collect(Collectors.groupingBy(PostReaction::getReactionType, Collectors.counting()))
                .entrySet().stream()
                .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue()))
                .limit(2)
                .map(entry -> new PostReaction(post, entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }
}
