package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    int userId;

    @Column(name = "username", length = 50, nullable = false)
    String userName;

    @Column(name = "phone", length = 15)
    String phone;

    @Column(name = "password", length = 255, nullable = false)
    String password;

    @Column(nullable = false)
    String avatar;

    @Column(name = "otp", length = 10)
    String otp;

    @Column(name = "generate_otp_time")
    LocalDateTime generateOtpTime;

    @Column(name = "active")
    int active;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<UserRole> userRoles;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<Post> posts;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<VoucherExchange> voucherExchange;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<PCBuild> pcBuilds;
}
