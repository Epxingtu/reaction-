package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "postid")
    Long postId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    User user;

    @ManyToOne
    @JoinColumn(name = "postcategoryid", nullable = false)
    PostCategory postCategory;

    @Column(name = "posttitle")
    String postTitle;

    @Column(name = "postcontent")
    String postContent;

    @Column(name = "postimage")
    String postImage;

    @Column(name = "posttime")
    LocalDateTime postTime;

    @Column(name = "postStatus")
    int postStatus;

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<PostComment> postComment;
    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<PostReaction> postReaction;
}
