package com.example.demo.Repository;

import com.example.demo.entity.PostComment;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostCommentRepository extends CrudRepository<PostComment, Long> {
    List<PostComment> findByPost_PostId(Long postId);

}
