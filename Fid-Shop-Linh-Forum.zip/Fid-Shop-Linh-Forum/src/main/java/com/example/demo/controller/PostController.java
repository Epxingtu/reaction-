package com.example.demo.controller;

import com.example.demo.Service.PostService;
import com.example.demo.entity.Post;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;  // Thêm dòng này
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/home") // Sửa lại để dễ hiểu hơn, không dùng /api/posts cho giao diện người dùng
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    // Trang chủ hiển thị tất cả bài viết
    @GetMapping
    public String home(Model model) {
        Iterable<Post> posts = postService.getAllPosts();
        model.addAttribute("posts", posts);
        return "home";  // Trả về trang home.html
    }

    // Form tạo bài viết mới
    @GetMapping("/create")
    public String createPostForm(Model model) {
        model.addAttribute("post", new Post()); // Thêm đối tượng Post rỗng vào model để form có thể hiển thị
        return "createPost";  // Trả về trang tạo bài viết
    }

     // Xử lý khi người dùng gửi bài viết mới
     @PostMapping("/create")
     public String createPost(@ModelAttribute Post post, @RequestParam("postImage") MultipartFile postImage) {
         if (!postImage.isEmpty()) {
             // Kiểm tra định dạng file
             String imageName = postImage.getOriginalFilename();
             if (imageName != null && (imageName.endsWith(".jpg") || imageName.endsWith(".png") || imageName.endsWith(".jpeg"))) {
                 try {
                     // Lưu ảnh vào thư mục static/images
                     java.nio.file.Path imagePath = java.nio.file.Paths.get("src/main/resources/static/images/" + imageName);
                     postImage.transferTo(imagePath.toFile());
                     post.setPostImage(imageName); // Lưu tên ảnh vào database
                 } catch (Exception e) {
                     e.printStackTrace();
                     return "redirect:/home/create?error=fileUpload"; // Trả về lỗi nếu upload thất bại
                 }
             } else {
                 return "redirect:/home/create?error=invalidFile"; // Trả về lỗi nếu định dạng không hợp lệ
             }
         }

         postService.createPost(post);
         return "redirect:/home"; // Quay về trang chủ sau khi tạo thành công
     }


    // Lấy tất cả bài viết (API cho Frontend)
    @GetMapping("/api")
    public ResponseEntity<Iterable<Post>> getAllPosts() {
        Iterable<Post> posts = postService.getAllPosts();
        return new ResponseEntity<>(posts, HttpStatus.OK);
    }

    // Lấy bài viết theo ID
    @GetMapping("/api/{id}")
    public ResponseEntity<Post> getPostById(@PathVariable Long id) {
        Post post = postService.getPostByIdPost(id);
        return post != null ? new ResponseEntity<>(post, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Cập nhật bài viết
    @PutMapping("/api/{id}")
    public ResponseEntity<Post> updatePost(@PathVariable Long id, @RequestBody Post post) {
        if (post.getPostTitle() == null || post.getPostContent() == null || post.getPostTitle().isEmpty() || post.getPostContent().isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Trả về lỗi nếu dữ liệu không hợp lệ
        }

        Post updatedPost = postService.updatePost(id, post);
        return updatedPost != null ? new ResponseEntity<>(updatedPost, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    // Xóa bài viết
    @DeleteMapping("/api/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable Long id) {
        boolean isDeleted = postService.deletePost(id);
        return isDeleted ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
/*
    @PostMapping("/create")
    public String createPost(@ModelAttribute Post post, @RequestParam("postImage") MultipartFile postImage) {
        if (!postImage.isEmpty()) {
            // Kiểm tra định dạng file
            String imageName = postImage.getOriginalFilename();
            if (imageName != null && (imageName.endsWith(".jpg") || imageName.endsWith(".png") || imageName.endsWith(".jpeg"))) {
                try {
                    // Lưu ảnh vào thư mục static/images
                    java.nio.file.Path imagePath = java.nio.file.Paths.get("src/main/resources/static/images/" + imageName);
                    postImage.transferTo(imagePath.toFile());
                    post.setPostImage(imageName); // Lưu tên ảnh vào database (trường postImage là String)
                } catch (Exception e) {
                    e.printStackTrace();
                    return "redirect:/home/create?error=fileUpload"; // Trả về lỗi nếu upload thất bại
                }
            } else {
                return "redirect:/home/create?error=invalidFile"; // Trả về lỗi nếu định dạng không hợp lệ
            }
        }

        postService.createPost(post); // Lưu bài viết vào cơ sở dữ liệu
        return "redirect:/home"; // Quay về trang chủ sau khi tạo thành công
    }

}
*/