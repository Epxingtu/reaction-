package com.example.demo.controller;
import com.example.demo.Service.PostCommentService;
import com.example.demo.entity.PostComment;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/comments")
@RequiredArgsConstructor
public class PostCommentController {
    private final PostCommentService postCommentService;

    // Lấy tất cả bình luận của một bài viết
    @GetMapping("/post/{postId}")
    public ResponseEntity<List<PostComment>> getComments(@PathVariable Long postId) {
        List<PostComment> comments = postCommentService.getCommentsByPostId(postId);
        return ResponseEntity.ok(comments);
    }

    // Thêm bình luận mới
    @PostMapping("/post/{postId}")
    public ResponseEntity<PostComment> addComment(
            @PathVariable Long postId,
            @RequestBody String content
    ) {
        PostComment newComment = postCommentService.addComment(postId, content);
        return ResponseEntity.status(HttpStatus.CREATED).body(newComment);
    }

    // Xóa bình luận
    @DeleteMapping("/{commentId}")
    public ResponseEntity<Void> deleteComment(@PathVariable Long commentId) {
        postCommentService.deleteComment(commentId);
        return ResponseEntity.noContent().build();
    }

}
